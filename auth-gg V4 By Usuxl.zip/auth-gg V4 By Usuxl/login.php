<?php
error_reporting(0);
include ("api/authgg.php");
AuthGG::Initialize("120987", "UPyI1CJz83SxcgBAxw4T81Af0lLGok9bZp3");
//AuthGG::Initialize("AIDHERE", "SECRETHERE");
?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Login - Ostrà</title>
  <link rel="stylesheet" href="./style.css">
  <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">	
  <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">

  <!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->

</head>
<body>
<!-- partial:index.partial.html -->
<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->
    <h2 class="active"> Sign In </h2>



    <!-- Icon -->
    <div class="fadeIn first">
      <img src="https://i.imgur.com/KQRY1Lv.png" id="icon" alt="User Icon" />
    </div>

    <!-- Login Form -->
    <form class="login100-form validate-form" method="POST">
    <div class="wrap-input100 rs1 validate-input" data-validate = "Username is required">
      <input type="text" id="login" class="input100" name="username" placeholder="Username">
      <div class="wrap-input100 rs2 validate-input" data-validate="Password is required">
      <input class="input100" type="password" id="password" name="password" placeholder="Password">
      <input type="submit" id="login" name="login" class="login100-form-btn" value="Log In">
    </form>

    <!-- Remind Passowrd -->
    <div id="formFooter">
      <a class="underlineHover" href="register.php">No account?</a>
    </div>

  </div>
</div>

<!-- php -->

<?php
if (isset($_POST["login"]))
{
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    if (AuthGG::Login($username, $password))

    {
        echo '<div class="alert alert-solid alert-success mg-b-0" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
            <strong>
            Login Successful!
            </strong>
            <br>
            <br>';
        echo 'Username: ' . $_SESSION["username"];
        echo '<br>';
        echo 'Email: ' . $_SESSION["email"];
        echo '<br>';
        echo 'Expiry Date: ' . $_SESSION["expiry"];
        echo '<br>';
        echo 'Rank: ' . $_SESSION["rank"];
        echo '<br>';
        echo 'Variable: ' . $_SESSION["variable"];
        echo '<br>';
        echo 'Last Login: ' . $_SESSION["lastlogin"];
        echo '<br>';
        echo '</div>';

        header('location: home.php');
        exit();
    }

}
?>

<!-- partial -->

<!--===============================================================================================-->
<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>
  
</body>
</html>
