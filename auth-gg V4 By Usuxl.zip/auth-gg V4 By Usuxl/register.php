<?php
error_reporting(0);
include ("api/authgg.php");
AuthGG::Initialize("120987", "UPyI1CJz83SxcgBAxw4T81Af0lLGok9bZp3");
?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Register - Ostrà</title>
  <link rel="stylesheet" href="./style.css">
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">	
  <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">

</head>
<body>
<!-- partial:index.partial.html -->
<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->
    <h2 class="active"> SIGN UP </h2>



    <!-- Icon -->
    <div class="fadeIn first">
      <img src="https://i.imgur.com/KQRY1Lv.png" id="icon" alt="User Icon" />
    </div>

    <!-- Login Form -->
				<form class="login100-form validate-form" method="POST">
    <div class="wrap-input100 rs1 validate-input" data-validate = "Username is required">
      <input type="text" class="fadeIn second" name="login" placeholder="Your Username">
      <div class="wrap-input100 rs2 validate-input" data-validate="Password is required">
      <input type="text" class="input100" name="login" placeholder="Your Password">
      <div class="wrap-input100 rs3 validate-input" data-validate = "Email is required">
      <input type="text" class="input100" name="email" placeholder="Your email ">
      <div class="wrap-input100 rs4 validate-input" data-validate = "License is required">
      <input type="text" class="input100" name="license" placeholder="Your license">
      <input type="submit" name="register" class="fadeIn fourth" id="register" value="REGISTRE">
    </form>

    <!-- Remind Passowrd -->
    <div id="formFooter">
      <a class="underlineHover" href="login.php">Log in >></a>
    </div>

</div>


<!-- php -->

<?php
if (isset($_POST["register"]))
{
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $license = $_POST['license'];
    if (AuthGG::Register($username, $password, $email, $license))
    {

    }
    else
    {

    }
}
?>

<!-- partial -->
  
</body>
</html>
